﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inicident_UI
{
    internal class Program
    {
        static void Main(string[] args)
        {
              ExecuteTicket ext = new ExecuteTicket();
                ext.Menu();
           

            Console.ReadLine();
        }
    }
}
